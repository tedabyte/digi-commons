# Simple Commons
Some helper functions, dialogs etc used by multiple simple apps.</br>
For reporting bugs/features that affect multiple apps please use the <a href="https://github.com/SimpleMobileTools/General-Discussion">General Discussion</a> repository.
