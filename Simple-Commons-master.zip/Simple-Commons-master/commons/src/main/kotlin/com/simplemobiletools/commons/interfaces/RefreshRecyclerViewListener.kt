package com.simplemobiletools.commons.interfaces

interface RefreshRecyclerViewListener {
    fun refreshItems()
}
