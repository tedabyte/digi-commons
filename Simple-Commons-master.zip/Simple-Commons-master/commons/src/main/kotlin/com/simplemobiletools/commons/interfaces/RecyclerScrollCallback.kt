package com.simplemobiletools.commons.interfaces

interface RecyclerScrollCallback {
    fun onScrolled(scrollY: Int)
}
